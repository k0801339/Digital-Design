#/usr/bin/sh
# You may also learn the way using this shell script to run the
# Verilog simulation, and avoid typing again and again...
ncverilog hw7_1_test.v hw7_1.v +access+r
